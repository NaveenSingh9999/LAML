LAML for Windows
================

Installation:
1. Right-click "install.bat" and "Run as administrator"
2. Follow the installation prompts
3. Restart your command prompt
4. Type "laml version" to verify

Manual Installation:
1. Run PowerShell as Administrator
2. Execute: .\install.ps1

Uninstallation:
Run PowerShell as Administrator and execute:
.\install.ps1 -Uninstall

For support, visit: https://github.com/NaveenSingh9999/LAML
